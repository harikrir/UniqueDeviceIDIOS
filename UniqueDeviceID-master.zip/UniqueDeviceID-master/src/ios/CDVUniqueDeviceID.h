//
//  CDVUniqueDeviceID.h
//
//
//
    
#import <Foundation/Foundation.h>
#import <Cordova/CDVPlugin.h>

@interface CDVUniqueDeviceID : CDVPlugin

- (void)get:(CDVInvokedUrlCommand*)command;

@end

